<!--- Provide a general summary of the issue in the Title above, prefixed with (CheatFolder Name) -->

## Checklist:
<!-- Go over all the following points, and put an `x` in all the boxes that apply. -->
<!-- If you're unsure about any of these, don't hesitate to ask. We're here to help! -->
- [ ] Broken Cheat
- [ ] Multi-Region
- [ ] Versioning
- [ ] Wrong Game
- [ ] Other

## Description
<!-- Describe the issues -->

## Extra Information (only need to fill in if issuing for Broken Cheats)
**Type of 3DS:** [e.g. New 3DS, Old 3DS, 2DS]

**3DS Firmware Version:** [e.g. 11.6.0-39E]

**Method Used:** [e.g. LUMAS3DS 9.0 Plugin Loader, BOOTNTR]

**Game Version:** [e.g. 1.0, 1.1]

**Language & Region:** [e.g. English & USA]
