<!--- Provide a general summary of the issue in the Title above, prefixed with (CheatFolder Name) -->

## Description
<!-- Describe your changes ex: "Additional Cheat Codes" -->

## Types of changes
<!-- What types of changes does your code introduce? Put an `x` in all the boxes that apply: -->
- [ ] Cheat fix
- [ ] New cheats
- [ ] Regional fix / Addition
- [ ] Other

## Additional Notes
<!-- Any additional notes you may want to say: -->
